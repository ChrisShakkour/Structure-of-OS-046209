Dor Meshali 311510630
Chris Shakkour 208157826
